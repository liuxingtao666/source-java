select * from service order by id;
select * from account order by id;
select * from service_detail order by id;
select * from bill;
select * from bill_item;
select * from MONTH_DURATION;









