package com.tarena.entity;

import java.io.Serializable;

public class MonthDurationId implements Serializable {

	private static final long serialVersionUID = 5184006100165778409L;

	private Integer serviceId;
	private String monthId;

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public String getMonthId() {
		return monthId;
	}

	public void setMonthId(String monthId) {
		this.monthId = monthId;
	}

}
