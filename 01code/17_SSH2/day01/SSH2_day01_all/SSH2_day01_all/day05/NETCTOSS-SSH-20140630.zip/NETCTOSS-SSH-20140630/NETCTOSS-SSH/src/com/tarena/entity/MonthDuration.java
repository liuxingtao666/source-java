package com.tarena.entity;

public class MonthDuration {

	private MonthDurationId id;
	private Integer serviceDetailId;
	private Integer sofarDuration;

	public MonthDurationId getId() {
		return id;
	}

	public void setId(MonthDurationId id) {
		this.id = id;
	}

	public Integer getServiceDetailId() {
		return serviceDetailId;
	}

	public void setServiceDetailId(Integer serviceDetailId) {
		this.serviceDetailId = serviceDetailId;
	}

	public Integer getSofarDuration() {
		return sofarDuration;
	}

	public void setSofarDuration(Integer sofarDuration) {
		this.sofarDuration = sofarDuration;
	}

}
